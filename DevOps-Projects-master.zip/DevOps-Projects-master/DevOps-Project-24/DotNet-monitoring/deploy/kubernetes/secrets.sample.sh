kubectl create secret generic dotnet-demoapp \
--from-literal=weatherKey=CHANGEME \
--from-literal=aadAppSecret=CHANGEME