# Introducing CI/CD to your pipeline

The purpose of this lab is to introduce you to CI/CD. 

In this lab, you will:
- Begin CI/CD with Pipeline Trigger for automatic pipeline runs
- Automated deployment of your AKS Application
